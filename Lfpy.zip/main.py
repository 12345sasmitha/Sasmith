year= int(input("Enter a year:"))
if(year % 4== 0):
  print("the given year is leap year")
else:
    print("the given year is not a leap year")